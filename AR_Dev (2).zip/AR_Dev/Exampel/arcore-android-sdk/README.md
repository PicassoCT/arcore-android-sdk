Google AR SDK
=====================
Copyright (c) 2017 Google Inc.  All rights reserved.

[https://developers.google.com/ar/develop/java/getting-started](https://developers.google.com/ar/develop/java/getting-started)

Please note, we do not accept pull requests.

## Additional Notes

You must disclose the use of ARCore, and how it collects and processes data.
This can be done by displaying a prominent link to the site
"How Google uses data when you use our partners' sites or apps",
(located at www.google.com/policies/privacy/partners/, or any other URL Google
may provide from time to time).
