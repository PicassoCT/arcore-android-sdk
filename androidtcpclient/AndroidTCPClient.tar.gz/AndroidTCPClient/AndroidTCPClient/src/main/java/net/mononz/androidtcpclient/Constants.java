package net.mononz.androidtcpclient;

public class Constants {

    public static final String CLOSED_CONNECTION = "client_closed_connection";
    public static final String LOGIN_NAME = "client_login_name";

}